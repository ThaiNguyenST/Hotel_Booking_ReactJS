const NewHotel = () => {
  return (
    <div className="container-fluid h1 p-5 text-center">Post a new hotel</div>
  );
};

export default NewHotel;
