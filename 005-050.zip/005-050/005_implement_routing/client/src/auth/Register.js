const Register = () => {
  return (
    <div className="container-fluid h1 p-5 text-center">Register Page</div>
  );
};

export default Register;
