const Login = () => {
  return <div className="container-fluid h1 p-5 text-center">Login Page</div>;
};

export default Login;
